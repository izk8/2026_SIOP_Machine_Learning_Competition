Meta-analysis Coding Instructions

In the dev dataset zip file are four distinct files:
1) The README file (the file you are reading)
2) Construct definitions
3) dev_articles.csv
4) dev_submissiontemplate.csv

1) The README File contains the overview of the data and some instructions about using the files. Finish reading this file before accessing the other data file to know how they fit in with the competition. The development dataset contains a single meta analysis focused on reconstructing a coding sheet examining the relationship between interpersonal trust that individuals have and their well-being, in a cross-sectional level of analysis. This dataset is intended to provide a concrete example of the task for the test dataset where you are given a research question, and predictor, and outcome variables for a separate meta-analytic question.

2) The Construct definitions file is intended to provide clear guidance on the meta-analysis research questions and variables used in the development dataset. It is intended to be equivalent to how a researcher might describe their research question, and it reflects the variables included in the actual meta-analysis coding sheet.

For your meta-analysis pipeline, you must create a system that accepts a research question, a predictor variable description, and an outcome variable description, and a pdf. From those inputs, your pipeline must be able to extract all bivariate statistics related to those from the pdf, which may be found in tables, figures, or within the text. Your pipeline must be generalizable and not custom fit on a specific research paper. Therefore, the pipeline for all papers in the dev set must receive the same research question, predictor variable description, and outcome variable description, in the input. Only the pdfs can change. You are free to modify the research question, predictor variable, and outcome variable descriptions as you see fit. The pipeline must find all of the research question relevant effect sizes from the study, and convert them to Pearson's r and code them in the direction of trust and well-being (if needed). The output of the pipeline must be an aggregate effect size, which is simply the average of relevant effect sizes found.

3) The Development Phase Articles file provides a list of articles for you to code with your pipeline and receive feedback on its performance. Unfortunately, the organizers of the competition are not allowed to share the original pdf, so the articles must be downloaded by your team. The organizers, however, have restricted the articles to be ones where a pdf of the article can be located via Google Scholar. Each article has a study number associated with it, which is important for submitting pipeline attempts to the leaderboard.

4) The Dev Submissions Template file is a fillable csv that shows what you would submit to the leaderboard (with the aggregate effect sizes filled in each blank cell next to the study number. You will receive an error score (lower is better), and your highest submission will appear on the leaderboard.